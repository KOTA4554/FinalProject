package com.kh.spring.di.anno.vo;

public interface Job {
	
	void work(String place);
	
}
